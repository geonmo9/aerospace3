package com.example.aerospace

class Notice(
    var date: String,
    var name: String,
    var notice: String
)
