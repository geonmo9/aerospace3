package com.example.aerospace

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class UtilActivity1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_util1)
    }
}
